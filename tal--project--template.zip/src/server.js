import { App } from "./app.js";

const appInstance = new App();
appInstance.createServer();
